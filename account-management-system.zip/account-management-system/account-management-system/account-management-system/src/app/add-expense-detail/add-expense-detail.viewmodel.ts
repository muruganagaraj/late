export interface viewmodel {
    itemCode?: string;
    itemname?: string;
    quantity?: number;
    amount?: number;
}

export interface ExpensiveVM {
    BuyerId?: number;
    ExpenseDate: Date;
    TotalItemAmount?: number;
    IsGSTRequired?: boolean;
    GST?: number;
    TotalAmountWithGST?: number;
    Discount?: number;
    FinalAmount?: number;
    items?: viewmodel[];
}