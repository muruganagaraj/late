import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DialogData } from 'app/buyer-detail/buyer-detail.component';
import { viewmodel } from './add-gst.viewmodel';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';

import { StorageHelper } from 'app/storage/storageHelper';


@Component({
  selector: 'app-add-gst',
  templateUrl: './add-gst.component.html',
  styleUrls: ['./add-gst.component.scss']
})
export class AddGstComponent implements OnInit {
  public vm: viewmodel = {};
  constructor(
    public dialogRef: MatDialogRef<AddGstComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private http: HttpClient,
    public storageHelper: StorageHelper) { }

  ngOnInit() {
    if (this.dialogRef.componentInstance.data) {
      this.vm = this.convertVotoVM(this.dialogRef.componentInstance.data);
    } else {
      this.vm = {};
    }

  }

  private headers = new HttpHeaders({
    'Content-Type': 'application/json;charset=UTF-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key',
    //'Access-Control-Allow-Methods': 'POST,GET,OPTIONS'
  });

  onClick(): void {
    //let headers = new HttpHeaders().set('Content-Type', 'application/json');
    let headers: HttpHeaders = new HttpHeaders();
    headers.append('Content-Type', 'text/plain');
    headers.append('Access-Control-Allow-Origin', '*');
    headers.append('Access-Control-Allow-Methods', 'GET, POST,OPTIONS');
    headers.append('Accept', 'application/json');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');

    let data: viewmodel = this.vm;
    if (this.vm.Description && this.vm.GSTCode && this.vm.GST) {
      this.storageHelper.isBusy = true;
      if (this.vm.GSTId) {
        let options = { headers: headers, withCredentials: false };
        let jsonSaveObject = {
          GSTCode: this.vm.GSTCode,
          GST: this.vm.GST,
          Description: this.vm.Description,
          GSTId: this.vm.GSTId
        }
        let jsonString = JSON.stringify(jsonSaveObject);
        this.http.post('https://9xevwqphu2.execute-api.us-east-1.amazonaws.com/default/EDU_G_UpdateById',
          jsonString
          , options).subscribe(result => {
            var response = result;
            this.dialogRef.close(true);
          });
      } else {
        let options = { headers: headers, withCredentials: false };
        let jsonSaveObject = {
          GSTCode: this.vm.GSTCode,
          GST: this.vm.GST,
          Description: this.vm.Description
        }
        let jsonString = JSON.stringify(jsonSaveObject);
        this.http.post('https://28t1p40kz5.execute-api.us-east-1.amazonaws.com/default/EDU_G_Add ',
          jsonString
          , options).subscribe(result => {
            this.dialogRef.close(true);
            //location.reload();
            var response = result;
          });
      }
    } else {
      alert('model not valid');
    }
  }
  convertVotoVM(data: any): viewmodel {
    let modaldata: viewmodel = {};
    modaldata.GST = data.item.GST;
    modaldata.GSTCode = data.item.GSTCode;
    modaldata.Description = data.item.Description;
    modaldata.GSTId = data.item.GSTId
    return modaldata;
  }

  onCancelClick(): void {
    this.dialogRef.close();
  }
}
